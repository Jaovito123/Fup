"""
Leia uma matriz 4 × 4. Calcule a soma dos elementos que estão na diagonal principal. 
Use apenas um comando de repetição. Não use comandos nem funções do python ou de suas 
bibliotecas que já façam isso.
"""

matriz = []
soma = 0

limite_linha = 0

c = 0

i = 0
j = 0

while True:
    if limite_linha < 4:
        matriz.append([])
        limite_linha += 1

    if limite_linha == 4 and i < 4:
        matriz[i].append(int(input()))
        j += 1
        if j == 3:
            i += 1
            j = 0

    if i == 4:
        soma += matriz[c][c]
        c += 1
    if c == 3:
        break

for i in matriz:
    for j in i:
        print(j, end=" ")
    print()